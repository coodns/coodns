document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM 로드 완료');
    
    // DOM이 완전히 로드된 후 약간의 지연을 두고 초기화
    setTimeout(() => {
        console.log('초기화 시작');
        
        // localStorage에서 체크 상태 복원 (내부에서 reorganizeChecklistByCategory 호출함)
        restoreManualCheckStates();
        
        // 복원이 완료된 후 체크박스 이벤트 리스너 초기화 (DOM 재구성 후)
        setTimeout(() => {
            initManualCheckboxes();
            calculateAndDisplayScore();
            updateCategoryBoxCounts();
            console.log('체크박스 이벤트 리스너 재초기화 완료');
        }, 150);
        
        // 차트 생성
        initTrendChart();
        
        // 카테고리 토글 기능
        initCategoryToggles();
        
        // 모든 카테고리 접기/펼치기 버튼
        initToggleAllButton();
        
        // 반응형 기능 초기화
        initResponsiveFeatures();
        
        // 모바일 터치 최적화
        initMobileOptimizations();
        
        // 리사이즈 이벤트 처리
        initResizeHandler();
        
        // 보고서 다운로드(인쇄) 기능
        initDownloadButton();
        
        // 카테고리 박스 클릭 스크롤 기능
        initCategoryBoxScrolling();
        
        console.log('초기화 완료');
    }, 200); // 200ms 지연
});

// 카테고리별 체크리스트 재구성 함수
function reorganizeChecklistByCategory() {
    console.log('카테고리별 체크리스트 재구성 시작...');
    
    // 영문-한글 카테고리 매핑
    const categoryMapping = {
        'General Check': '일반 설정',
        'Security Check': '보안',
        'Scalability Check': '확장성',
        'Stability Check': '안정성',
        'Reliability Check': '안정성',
        'Network Check': '네트워크',
        'Cost-Optimized Check': '비용'
    };
    
    // 상태별 정보
    const statusInfo = {
        'FAIL': {
            title: '조치 필요',
            icon: 'bi-x-circle',
            iconClass: 'danger-bg',
            bgClass: 'fail-bg',
            image: 'ico-failure.svg'
        },
        'MANUAL': {
            title: '점검 필요',
            icon: 'bi-exclamation-triangle',
            iconClass: 'warning-bg',
            bgClass: 'manual-bg',
            image: 'ico-inspection.svg'
        },
        'PASS': {
            title: '조치 완료',
            icon: 'bi-check-circle',
            iconClass: 'success-bg',
            bgClass: 'pass-bg',
            image: 'ico-pass.svg'
        }
    };
    
    // 기존 섹션들에서 모든 체크 항목 수집
    const categoryGroups = {};
    
    // 원본 섹션들에서 데이터 수집
    const originalSections = document.querySelectorAll('#original-sections .check-item');
    
    originalSections.forEach(item => {
        const categoryName = item.dataset.categoryName;
        const status = item.dataset.status;
        
        if (!categoryName || !status) return;
        
        const koreanCategory = categoryMapping[categoryName] || categoryName;
        
        if (!categoryGroups[koreanCategory]) {
            categoryGroups[koreanCategory] = {
                'FAIL': [],
                'MANUAL': [],
                'PASS': []
            };
        }
        
        // 아이템 복제해서 저장
        const clonedItem = item.cloneNode(true);
        
        // 체크박스 ID 중복 문제 해결
        const checkbox = clonedItem.querySelector('.manual-checkbox');
        const label = clonedItem.querySelector('.form-check-label');
        
        if (checkbox && checkbox.id) {
            const originalId = checkbox.id;
            const newId = `${originalId}-categorized-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
            checkbox.id = newId;
            
            if (label && label.getAttribute('for') === originalId) {
                label.setAttribute('for', newId);
            }
            
            console.log(`🔧 체크박스 ID 수정: ${originalId} → ${newId}`);
        }
        
        categoryGroups[koreanCategory][status].push(clonedItem);
    });
    
    console.log('수집된 카테고리 그룹:', Object.keys(categoryGroups));
    
    // 카테고리별 섹션 생성
    const container = document.getElementById('category-by-type-container');
    
    // 카테고리 순서 정의
    const categoryOrder = ['일반 설정', '보안', '확장성', '안정성', '네트워크', '비용'];
    
    categoryOrder.forEach(categoryName => {
        if (!categoryGroups[categoryName]) return;
        
        const categorySection = createCategorySection(categoryName, categoryGroups[categoryName], statusInfo);
        container.appendChild(categorySection);
    });
    
    console.log('카테고리별 체크리스트 재구성 완료');
}

// 카테고리 섹션 생성 함수
function createCategorySection(categoryName, statusGroups, statusInfo) {
    const categorySection = document.createElement('div');
    categorySection.className = 'category-section';
    
    // 전체 항목 수 계산
    const totalItems = Object.values(statusGroups).reduce((sum, items) => sum + items.length, 0);
    
    // 카테고리 헤더 생성
    const categoryHeader = document.createElement('div');
    categoryHeader.className = 'category-title active';
    categoryHeader.setAttribute('data-category', categoryName);
    categoryHeader.innerHTML = `
        <h3>
            <span class="category-icon" style="background-color: #e0e7ff; color: #2563eb;">
                <i class="bi bi-folder"></i>
            </span>
            ${categoryName} (${totalItems})
        </h3>
        <span class="toggle-icon">
            <i class="bi bi-chevron-down"></i>
        </span>
    `;
    
    // 카테고리 콘텐츠 생성
    const categoryContent = document.createElement('div');
    categoryContent.className = 'category-content';
    categoryContent.style.display = 'block';
    
    // 상태별 순서 (조치 필요 -> 점검 필요 -> 조치 완료)
    const statusOrder = ['FAIL', 'MANUAL', 'PASS'];
    
    statusOrder.forEach(status => {
        const items = statusGroups[status];
        if (items.length === 0) return;
        
        const statusSection = createStatusSubSection(status, items, statusInfo[status]);
        categoryContent.appendChild(statusSection);
    });
    
    categorySection.appendChild(categoryHeader);
    categorySection.appendChild(categoryContent);
    
    // 토글 이벤트 리스너 추가
    categoryHeader.addEventListener('click', function() {
        this.classList.toggle('active');
        
        if (categoryContent.style.display === "block") {
            categoryContent.style.display = "none";
        } else {
            categoryContent.style.display = "block";
        }
        
        // 모바일에서 스크롤 조정
        if (window.innerWidth < 768) {
            setTimeout(() => {
                this.scrollIntoView({ 
                    behavior: 'smooth', 
                    block: 'nearest'
                });
            }, 300);
        }
    });
    
    return categorySection;
}

// 상태별 하위 섹션 생성 함수
function createStatusSubSection(status, items, statusInfo) {
    const subSection = document.createElement('div');
    subSection.className = 'status-subsection';
    subSection.style.marginBottom = '1.5rem';
    
    // 하위 섹션 헤더
    const subHeader = document.createElement('div');
    subHeader.className = 'sub-category-title';
    subHeader.style.cssText = `
        padding: 0.75rem 1rem;
        background-color: #f8fafc;
        border-left: 4px solid var(--${status === 'FAIL' ? 'danger' : status === 'MANUAL' ? 'warning' : 'success'}-color);
        margin-bottom: 1rem;
        font-weight: 600;
        border-radius: 6px;
    `;
    // subHeader.innerHTML = `
    //     <span class="status-icon" style="margin-right: 0.5rem;">
    //         <i class="bi ${statusInfo.icon}"></i>
    //     </span>
    //     ${statusInfo.title} (${items.length})
    // `;
    subHeader.innerHTML = `
        <h3>
            <i class="category-icon ${statusInfo.iconClass}"><img src="./images/${statusInfo.image}" alt="${statusInfo.title}" style="width: 30px;"></i>
             ${statusInfo.title} <span>(${items.length})</span>
        </h3>
    `
    
    // 항목들 컨테이너
    const itemsContainer = document.createElement('div');
    itemsContainer.className = 'status-items';
    
    // items가 배열인지 확인하고 추가
    if (Array.isArray(items)) {
        items.forEach(item => {
            itemsContainer.appendChild(item);
        });
    }
    
    subSection.appendChild(subHeader);
    subSection.appendChild(itemsContainer);
    
    // 항목이 없으면 섹션 숨기기 (동적으로 추가될 수 있으므로 초기에는 보이도록)
    if (items.length === 0) {
        subSection.style.display = 'none';
    }
    
    return subSection;
}

// 메뉴얼 체크박스 초기화 함수
function initManualCheckboxes() {
    // 새로 생성된 카테고리별 섹션에서만 체크박스 찾기 (원본 섹션 제외)
    const checkboxes = document.querySelectorAll('#category-by-type-container .manual-checkbox');
    console.log(`📋 체크박스 초기화: ${checkboxes.length}개의 체크박스 발견 (카테고리별 섹션에서)`);
    
    // 원본 섹션의 체크박스도 확인 (디버깅용)
    const originalCheckboxes = document.querySelectorAll('#original-sections .manual-checkbox');
    console.log(`🔍 원본 섹션 체크박스: ${originalCheckboxes.length}개 (숨겨짐)`);
    
    // 각 체크박스에 이벤트 리스너 추가
    checkboxes.forEach((checkbox, index) => {
        // 기존 이벤트 리스너가 있을 수 있으므로 제거 후 추가
        const newCheckbox = checkbox.cloneNode(true);
        checkbox.parentNode.replaceChild(newCheckbox, checkbox);
        
        newCheckbox.addEventListener('change', function() {
            console.log(`✅ 체크박스 ${index + 1} 클릭됨:`, this.checked);
            
            // MANUAL 아이템인지 PASS 아이템인지 확인
            const manualItem = this.closest('.manual-item');
            const passItem = this.closest('.pass-item');
            
            console.log(`🔍 아이템 타입 확인:`, {
                manualItem: !!manualItem,
                passItem: !!passItem
            });
            
            if (manualItem) {
                // MANUAL 아이템 처리
                console.log(`📂 MANUAL 아이템 데이터 속성 확인:`);
                console.log(`  - checkName: ${manualItem.dataset.checkName}`);
                console.log(`  - category: ${manualItem.dataset.category}`);
                console.log(`  - categoryName: ${manualItem.dataset.categoryName}`);
                console.log(`  - status: ${manualItem.dataset.status}`);
                
                const checkName = manualItem.dataset.checkName;
                console.log(`📝 최종 체크 항목 이름: ${checkName}`);
                
                if (this.checked && checkName) {
                    console.log(`💾 localStorage에 저장 중: ${checkName}`);
                    // 체크 상태를 localStorage에 저장
                    saveManualCheckState(checkName, true);
                    
                    console.log(`➡️ PASS 섹션으로 이동 시작: ${checkName}`);
                    // 항목을 PASS 섹션으로 이동
                    moveItemToPass(this);
                } else if (!this.checked && checkName) {
                    console.log(`🗑️ localStorage에서 제거: ${checkName}`);
                    // 체크 해제 시 localStorage에서 제거
                    saveManualCheckState(checkName, false);
                } else {
                    console.error(`❌ MANUAL 체크박스 처리 실패`);
                    console.error(`  - checkName: ${checkName}`);
                    console.error(`  - checked: ${this.checked}`);
                }
            } else if (passItem) {
                // PASS 아이템 처리
                console.log(`📂 PASS 아이템 데이터 속성 확인:`);
                console.log(`  - checkName: ${passItem.dataset.checkName}`);
                console.log(`  - category: ${passItem.dataset.category}`);
                console.log(`  - categoryName: ${passItem.dataset.categoryName}`);
                
                const checkName = passItem.dataset.checkName;
                console.log(`📝 최종 체크 항목 이름: ${checkName}`);
                
                if (!this.checked && checkName) {
                    console.log(`🔄 MANUAL 섹션으로 되돌리기 시작: ${checkName}`);
                    // 체크 해제 시 MANUAL 섹션으로 되돌리기
                    moveItemToManual(this);
                } else if (this.checked && checkName) {
                    console.log(`💾 PASS 상태 localStorage에 저장: ${checkName}`);
                    // 체크 상태를 localStorage에 저장 (재체크 시)
                    saveManualCheckState(checkName, true);
                } else {
                    console.error(`❌ PASS 체크박스 처리 실패`);
                    console.error(`  - checkName: ${checkName}`);
                    console.error(`  - checked: ${this.checked}`);
                }
            } else {
                console.error(`❌ .manual-item 또는 .pass-item을 찾을 수 없습니다!`);
                console.log(`🔍 체크박스 부모 요소들:`, this.parentElement, this.parentElement?.parentElement);
                return;
            }
        });
        
        console.log(`✓ 체크박스 ${index + 1} 이벤트 리스너 연결 완료`);
    });
    
    console.log(`🎯 총 ${checkboxes.length}개의 체크박스 이벤트 리스너 초기화 완료`);
}

// 항목을 PASS 섹션으로 이동하는 함수
function moveItemToPass(checkbox) {
    console.log(`🚀 moveItemToPass 함수 시작`);
    console.log(`📋 체크박스:`, checkbox);
    
    const manualItem = checkbox.closest('.manual-item');
    if (!manualItem) {
        console.error('❌ manual-item을 찾을 수 없습니다.');
        console.log(`🔍 체크박스 주변 요소:`, checkbox.parentElement, checkbox.parentElement?.parentElement);
        return;
    }
    
    console.log(`✅ manual-item 찾음:`, manualItem);
    
    const checkName = manualItem.dataset.checkName;
    const category = manualItem.dataset.category;
    const categoryName = manualItem.dataset.categoryName;
    
    console.log(`📊 이동할 항목 정보:`);
    console.log(`  - checkName: ${checkName}`);
    console.log(`  - category: ${category}`);
    console.log(`  - categoryName: ${categoryName}`);
    
    if (!checkName || !categoryName) {
        console.error(`❌ 필수 데이터가 없습니다 - checkName: ${checkName}, categoryName: ${categoryName}`);
        return;
    }
    
    // 영문-한글 카테고리 매핑
    const categoryMapping = {
        'General Check': '일반 설정',
        'Security Check': '보안',
        'Scalability Check': '확장성',
        'Stability Check': '안정성',
        'Reliability Check': '안정성',
        'Network Check': '네트워크',
        'Cost-Optimized Check': '비용'
    };
    
    const koreanCategory = categoryMapping[categoryName] || categoryName;
    console.log(`🏷️ 한글 카테고리: ${koreanCategory} (원본: ${categoryName})`);
    
    // 모든 카테고리 섹션 확인 (디버깅용)
    const allCategorySections = document.querySelectorAll('#category-by-type-container .category-section');
    console.log(`📁 전체 카테고리 섹션 수: ${allCategorySections.length}`);
    allCategorySections.forEach((section, index) => {
        const title = section.querySelector('.category-title h3');
        const titleText = title ? title.textContent.trim() : 'No title';
        console.log(`  [${index}] ${titleText}`);
    });
    
    // 해당 카테고리의 PASS 하위 섹션 찾기
    const categorySection = Array.from(allCategorySections).find(section => {
        const title = section.querySelector('.category-title h3');
        const titleText = title ? title.textContent.trim() : '';
        const includes = titleText.includes(koreanCategory);
        console.log(`🔍 카테고리 매칭 확인: "${titleText}" includes "${koreanCategory}" = ${includes}`);
        return title && includes;
    });
    
    if (!categorySection) {
        console.error(`❌ 카테고리 섹션을 찾을 수 없습니다: ${koreanCategory}`);
        console.log(`📝 찾으려는 한글 카테고리: "${koreanCategory}"`);
        console.log(`📝 사용 가능한 카테고리들:`);
        allCategorySections.forEach(section => {
            const title = section.querySelector('.category-title h3');
            if (title) console.log(`  - "${title.textContent.trim()}"`);
        });
        return;
    }
    
    console.log(`✅ 카테고리 섹션 찾음:`, categorySection);
    
    // 해당 카테고리 내에서 조치 완료(PASS) 하위 섹션 찾기 또는 생성
    let passContainer = null;
    
    const subSections = categorySection.querySelectorAll('.status-subsection');
    for (const subSection of subSections) {
        const subTitle = subSection.querySelector('.sub-category-title');
        if (subTitle && subTitle.textContent.includes('조치 완료')) {
            passContainer = subSection.querySelector('.status-items');
            break;
        }
    }
    
    // 조치 완료 섹션이 없으면 생성
    if (!passContainer) {
        const statusInfo = {
            title: '조치 완료',
            icon: 'bi-check-circle',
            iconClass: 'success-bg',
            bgClass: 'pass-bg',
            image: 'ico-pass.svg'
        };
        
        const newPassSubSection = createStatusSubSection('PASS', [], statusInfo);
        const categoryContent = categorySection.querySelector('.category-content');
        categoryContent.appendChild(newPassSubSection);
        
        passContainer = newPassSubSection.querySelector('.status-items');
    }
    
    // 기존 MANUAL 아이템에서 이유와 런북 링크 추출하여 보존
    const reasonElement = manualItem.querySelector('.check-reason');
    const reasonHTML = reasonElement ? reasonElement.innerHTML : '';
    const runbookLink = manualItem.querySelector('.runbook-link');
    const runbookHref = runbookLink ? runbookLink.getAttribute('href') : '';
    // 영향받는 리소스 블록 추출 (code-card 포함 영역)
    const resourceContainer = manualItem.querySelector('.mb-3');
    const resourceHTML = resourceContainer ? resourceContainer.innerHTML : '';

    // 새로운 PASS 아이템 생성 (이유/링크/리소스 보존)
    const newPassItem = createPassItem(checkName, category, reasonHTML, runbookHref, resourceHTML);
    
    // 데이터 속성 설정
    newPassItem.dataset.categoryName = categoryName;
    newPassItem.dataset.status = 'PASS';
    
    // PASS 섹션에 추가
    passContainer.appendChild(newPassItem);
    console.log(`PASS 섹션에 ${checkName} 항목 추가 완료`);
    
    // localStorage에 체크 상태 저장 (이유/링크 포함)
    saveManualCheckState(checkName, true, {
        reasonHTML,
        runbookHref,
        resourceHTML
    });
    
    // 기존 MANUAL 아이템 제거
    manualItem.remove();
    console.log(`MANUAL 섹션에서 ${checkName} 항목 제거 완료`);
    
    // 새로 생성된 PASS 아이템의 체크박스에 이벤트 리스너 추가
    setTimeout(() => {
        initManualCheckboxes();
    }, 50);
    
    // 하위 섹션 항목 수 업데이트
    updateSubSectionCounts(categorySection);
    
    // DOM 업데이트 후 약간의 지연을 두고 카운트 업데이트
    setTimeout(() => {
        console.log('카운트 업데이트 시작...');
        
        // 카테고리 카운트 업데이트
        updateCategoryCounts();
        
        // 점수 재계산
        calculateAndDisplayScore();
        
        // 성공 메시지 표시
        showSuccessMessage(checkName);
        
        console.log('카운트 업데이트 완료');
    }, 100); // 100ms 지연
}

// PASS 아이템 생성 함수
function createPassItem(checkName, category, reasonHTML = '', runbookHref = '', resourceHTML = '') {
    const passItem = document.createElement('div');
    passItem.className = 'check-item pass-item';
    passItem.dataset.checkName = checkName;
    passItem.dataset.category = category;
    // 보존용 데이터 속성 저장
    if (runbookHref) passItem.dataset.runbookHref = runbookHref;
    if (reasonHTML) passItem.dataset.reasonHtml = reasonHTML;
    if (resourceHTML) passItem.dataset.resourceHtml = resourceHTML;
    
    // 체크박스용 고유 ID 생성
    const checkboxId = `pass-check-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    
    passItem.innerHTML = `
        <div class="check-header pass-bg">
            <div class="d-flex align-items-center">
                <span class="status-icon">
                    <i class="bi bi-check-circle-fill"></i>
                </span>
                <span>${checkName}</span>
            </div>
            <div class="category-tag">
                <i class="bi bi-folder me-1"></i>${category}
            </div>
        </div>
        <div class="check-body">
            <div class="d-flex justify-content-between align-items-center">
                <div class="alert alert-warning mb-0 flex-grow-1 me-3">
                    <i class="bi bi-check-circle me-2"></i>
                    수동 검토 완료됨
                </div>
            </div>
            ${reasonHTML ? `<div class="check-reason" style="display: none;">${reasonHTML}</div>` : ''}
            <div class="d-flex justify-content-between align-items-center">
                <a href="${runbookHref || ''}" target="_blank" class="runbook-link">
                    <i class="ico-guide"></i>가이드 보러가기
                </a>    
                <div class="form-check">
                    <input class="form-check-input manual-checkbox" type="checkbox" id="${checkboxId}" checked data-item-id="${checkName}">
                    <label class="form-check-label" for="${checkboxId}">
                        <i class="bi bi-exclamation-triangle me-1"></i>검토 완료
                    </label>
                </div>
            </div>
        </div>
    `;
    
    return passItem;
}

// 항목을 MANUAL 섹션으로 되돌리는 함수
function moveItemToManual(checkbox) {
    console.log(`🔄 moveItemToManual 함수 시작`);
    console.log(`📋 체크박스:`, checkbox);
    
    const passItem = checkbox.closest('.pass-item');
    if (!passItem) {
        console.error('❌ pass-item을 찾을 수 없습니다.');
        return;
    }
    
    console.log(`✅ pass-item 찾음:`, passItem);
    
    const checkName = passItem.dataset.checkName;
    const category = passItem.dataset.category;
    const categoryName = passItem.dataset.categoryName;
    
    console.log(`📊 되돌릴 항목 정보:`);
    console.log(`  - checkName: ${checkName}`);
    console.log(`  - category: ${category}`);
    console.log(`  - categoryName: ${categoryName}`);
    
    if (!checkName) {
        console.error(`❌ checkName이 없습니다: ${checkName}`);
        return;
    }
    
    // 영문-한글 카테고리 매핑
    const categoryMapping = {
        'General Check': '일반 설정',
        'Security Check': '보안',
        'Scalability Check': '확장성',
        'Stability Check': '안정성',
        'Reliability Check': '안정성',
        'Network Check': '네트워크',
        'Cost-Optimized Check': '비용'
    };
    
    // categoryName이 없으면 category를 사용
    const actualCategoryName = categoryName || category;
    const koreanCategory = categoryMapping[actualCategoryName] || actualCategoryName;
    console.log(`🏷️ 한글 카테고리: ${koreanCategory} (원본: ${actualCategoryName})`);
    
    // 해당 카테고리 섹션 찾기
    const allCategorySections = document.querySelectorAll('#category-by-type-container .category-section');
    const categorySection = Array.from(allCategorySections).find(section => {
        const title = section.querySelector('.category-title h3');
        const titleText = title ? title.textContent.trim() : '';
        return title && titleText.includes(koreanCategory);
    });
    
    if (!categorySection) {
        console.error(`❌ 카테고리 섹션을 찾을 수 없습니다: ${koreanCategory}`);
        return;
    }
    
    console.log(`✅ 카테고리 섹션 찾음:`, categorySection);
    
    // 해당 카테고리 내에서 점검 필요(MANUAL) 하위 섹션 찾기 또는 생성
    let manualContainer = null;
    
    const subSections = categorySection.querySelectorAll('.status-subsection');
    for (const subSection of subSections) {
        const subTitle = subSection.querySelector('.sub-category-title');
        if (subTitle && subTitle.textContent.includes('점검 필요')) {
            manualContainer = subSection.querySelector('.status-items');
            break;
        }
    }
    
    // 점검 필요 섹션이 없으면 생성
    if (!manualContainer) {
        const statusInfo = {
            title: '점검 필요',
            icon: 'bi-exclamation-triangle',
            iconClass: 'warning-bg',
            bgClass: 'manual-bg',
            image: 'ico-inspection.svg'
        };
        
        const newManualSubSection = createStatusSubSection('MANUAL', [], statusInfo);
        const categoryContent = categorySection.querySelector('.category-content');
        
        // 점검 필요 섹션을 조치 완료 섹션 앞에 삽입
        const passSubSection = categoryContent.querySelector('.status-subsection');
        if (passSubSection) {
            categoryContent.insertBefore(newManualSubSection, passSubSection);
        } else {
            categoryContent.appendChild(newManualSubSection);
        }
        
        manualContainer = newManualSubSection.querySelector('.status-items');
    }
    
    // 기존 PASS 아이템에서 이유와 런북 링크 추출 (보존)
    const reasonElement = passItem.querySelector('.check-reason');
    const reasonHTML = reasonElement ? reasonElement.innerHTML : '';
    const runbookLink = passItem.querySelector('.runbook-link');
    const runbookHref = runbookLink ? runbookLink.getAttribute('href') : '';
    // PASS에 보존해둔 리소스 블록 복원용 추출
    const resourceContainer = passItem.querySelector('.mb-3');
    const resourceHTML = resourceContainer ? resourceContainer.innerHTML : (passItem.dataset.resourceHtml || '');

    // 새로운 MANUAL 아이템 생성 (이유/링크/리소스 보존)
    const newManualItem = createManualItem(checkName, category, actualCategoryName, reasonHTML, runbookHref, resourceHTML);
    
    // 데이터 속성 설정
    newManualItem.dataset.categoryName = actualCategoryName;
    newManualItem.dataset.status = 'MANUAL';
    
    // MANUAL 섹션에 추가
    manualContainer.appendChild(newManualItem);
    console.log(`MANUAL 섹션에 ${checkName} 항목 추가 완료`);
    
    // localStorage 상태 업데이트 (체크 해제 + 이유/링크 보존)
    saveManualCheckState(checkName, false, {
        reasonHTML,
        runbookHref,
        resourceHTML
    });
    
    // 기존 PASS 아이템 제거
    passItem.remove();
    console.log(`PASS 섹션에서 ${checkName} 항목 제거 완료`);
    
    // 하위 섹션 항목 수 업데이트
    updateSubSectionCounts(categorySection);
    
    // DOM 업데이트 후 약간의 지연을 두고 카운트 업데이트
    setTimeout(() => {
        console.log('카운트 업데이트 시작...');
        
        // 카테고리 카운트 업데이트
        updateCategoryCounts();
        
        // 점수 재계산
        calculateAndDisplayScore();
        
        // 체크박스 이벤트 리스너 재초기화 (새로 생성된 MANUAL 아이템용)
        initManualCheckboxes();
        
        // 성공 메시지 표시
        showUndoMessage(checkName);
        
        console.log('카운트 업데이트 완료');
    }, 100); // 100ms 지연
}

// MANUAL 아이템 생성 함수
function createManualItem(checkName, category, categoryName, reasonHTML = '', runbookHref = '', resourceHTML = '') {
    const manualItem = document.createElement('div');
    manualItem.className = 'check-item manual-item';
    manualItem.dataset.checkName = checkName;
    manualItem.dataset.category = category;
    manualItem.dataset.categoryName = categoryName;
    if (runbookHref) manualItem.dataset.runbookHref = runbookHref;
    if (reasonHTML) manualItem.dataset.reasonHtml = reasonHTML;
    if (resourceHTML) manualItem.dataset.resourceHtml = resourceHTML;
    
    // 체크박스용 고유 ID 생성
    const checkboxId = `manual-check-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    
    manualItem.innerHTML = `
        <div class="check-header manual-bg">
            <div class="d-flex align-items-center">
                <span class="status-icon">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                </span>
                <span>${checkName}</span>
            </div>
            <div class="category-tag">
                <i class="bi bi-folder me-1"></i>${category}
            </div>
        </div>
        <div class="check-body">
            ${reasonHTML ? `<div class=\"check-reason\">${reasonHTML}</div>` : `
            <div class=\"check-reason\">
                <strong><i class=\"bi bi-info-circle me-2\"></i>이유:</strong>
            </div>`}
            ${resourceHTML ? `<div class=\"mb-3\">${resourceHTML}</div>` : ''}
            <div class="d-flex justify-content-between align-items-center">
                <a href="${runbookHref || ''}" target="_blank" class="runbook-link">
                    <i class="ico-guide"></i>가이드 보러가기
                </a>
                <div class="form-check">
                    <input class="form-check-input manual-checkbox" type="checkbox" id="${checkboxId}" data-item-id="${checkName}">
                    <label class="form-check-label" for="${checkboxId}">
                        <i class="bi bi-check-circle me-1"></i>검토 완료
                    </label>
                </div>
            </div>
        </div>
    `;
    
    return manualItem;
}

// 체크 해제 메시지 표시 함수
function showUndoMessage(checkName) {
    // 간단한 토스트 메시지 생성
    const toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.innerHTML = `
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <i class="bi bi-arrow-counterclockwise me-2"></i>
            <strong>${checkName}</strong> 항목이 점검 필요 상태로 되돌려졌습니다.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    // 페이지 상단에 추가
    document.body.prepend(toast);
    
    // 3초 후 자동 제거
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// 하위 섹션 카운트 업데이트 함수
function updateSubSectionCounts(categorySection) {
    const subSections = categorySection.querySelectorAll('.status-subsection');
    let totalItems = 0;
    
    subSections.forEach(subSection => {
        const items = subSection.querySelectorAll('.check-item');
        const count = items.length;
        totalItems += count;
        
        // 하위 섹션 제목의 카운트 업데이트
        const subTitle = subSection.querySelector('.sub-category-title');
        if (subTitle) {
            const titleText = subTitle.textContent.replace(/\(\d+\)/, `(${count})`);
            subTitle.innerHTML = subTitle.innerHTML.replace(/\(\d+\)/, `(${count})`);
        }
        
        // 항목이 없으면 하위 섹션 숨기기
        if (count === 0) {
            subSection.style.display = 'none';
        } else {
            subSection.style.display = 'block';
        }
    });
    
    // 카테고리 전체 카운트 업데이트
    const categoryTitle = categorySection.querySelector('.category-title h3');
    if (categoryTitle) {
        const titleText = categoryTitle.textContent.replace(/\(\d+\)/, `(${totalItems})`);
        categoryTitle.innerHTML = categoryTitle.innerHTML.replace(/\(\d+\)/, `(${totalItems})`);
    }
}

// 카테고리 카운트 업데이트 함수
function updateCategoryCounts() {
    // 각 카테고리의 항목 개수 계산 - 더 안정적인 방법 사용
    const passItems = getItemCountByCategory('PASS');
    const failItems = getItemCountByCategory('FAIL');
    const manualItems = getItemCountByCategory('MANUAL');
    
    // 헤더의 카운트 업데이트
    updateCategoryHeaderCount('PASS', passItems);
    updateCategoryHeaderCount('FAIL', failItems);
    updateCategoryHeaderCount('MANUAL', manualItems);
    
    // 상단 요약 영역의 카운트 업데이트
    updateSummaryCount('pass', passItems);
    updateSummaryCount('fail', failItems);
    updateSummaryCount('check', manualItems);
    
    // 항목별 점검 결과 섹션 카운트 업데이트 추가
    updateCategoryBoxCounts();
}

// 항목별 점검 결과 섹션의 카테고리 박스 카운트 업데이트 함수
function updateCategoryBoxCounts() {
    console.log('항목별 점검 결과 카운트 업데이트 시작');
    
    // 카테고리별 카운트 계산
    const categoryCounts = calculateCategoryCountsByName();
    
    // 각 카테고리 박스 업데이트
    const categoryBoxes = document.querySelectorAll('.category-box');
    
    categoryBoxes.forEach((box, boxIndex) => {
        const categoryTitle = box.querySelector('h3').textContent.trim();
        const counts = categoryCounts[categoryTitle];
        
        console.log(`박스 ${boxIndex}: "${categoryTitle}" 카테고리 처리 중...`);
        
        if (counts) {
            console.log(`${categoryTitle} 카테고리 카운트 업데이트: Pass=${counts.pass}, Fail=${counts.fail}, Manual=${counts.manual}, Total=${counts.total}`);
            
            // result-fraction 업데이트 (통과/전체)
            const fractionElement = box.querySelector('.result-fraction');
            if (fractionElement) {
                fractionElement.textContent = `${counts.pass}/${counts.total}`;
                console.log(`  ${categoryTitle} fraction 업데이트: ${counts.pass}/${counts.total}`);
            }
            
            // result-icons 전체 재생성
            const resultIconsElement = box.querySelector('.result-icons');
            if (resultIconsElement) {
                // resultIconsElement.innerHTML = `
                //     <span class="icon-group">
                //         <i class="bi bi-check-circle-fill text-success"></i> ${counts.pass}
                //     </span>
                //     <span class="icon-group">
                //         <i class="bi bi-exclamation-triangle-fill text-warning"></i> ${counts.manual}
                //     </span>
                //     <span class="icon-group">
                //         <i class="bi bi-x-circle-fill text-danger"></i> ${counts.fail}
                //     </span>
                // `;
                resultIconsElement.innerHTML = `
                    <div class="icon-group">
                        <p>조치완료</p>
                        <span>
                            <i class="text-success"><img src="./images/ico-pass.svg" alt=""></i>${counts.pass}
                        </span>
                    </div>
                    <div class="icon-group">
                        <p>조치필요</p>
                        <span>
                            <i class="text-secondary"><img src="./images/ico-failure.svg" alt=""></i>${counts.fail}
                        </span>
                    </div>
                    <div class="icon-group">
                        <p>검토필요</p>
                        <span>
                            <i class="text-danger"><img src="./images/ico-inspection.svg" alt=""></i>${counts.manual}
                        </span>
                    </div>
                `
                console.log(`  ${categoryTitle} icons 업데이트 완료`);
            }
        } else {
            console.warn(`카테고리 "${categoryTitle}"에 대한 카운트 데이터를 찾을 수 없습니다.`);
            console.log('사용 가능한 카테고리:', Object.keys(categoryCounts));
        }
    });
    
    console.log('항목별 점검 결과 카운트 업데이트 완료');
}

// 카테고리별 카운트를 이름으로 계산하는 함수
function calculateCategoryCountsByName() {
    // 동적으로 카테고리 초기화
    const categoryCounts = {};
    
    // 기본 카테고리들 초기화
    const defaultCategories = ['일반 설정', '보안', '확장성', '안정성', '네트워크', '비용'];
    defaultCategories.forEach(cat => {
        categoryCounts[cat] = { pass: 0, fail: 0, manual: 0, total: 0 };
    });
    
    // 영문-한글 카테고리 매핑
    const categoryMapping = {
        'General Check': '일반 설정',
        'Security Check': '보안',
        'Scalability Check': '확장성',
        'Stability Check': '안정성',
        'Reliability Check': '안정성',
        'Network Check': '네트워크',
        'Cost-Optimized Check': '비용'
    };
    
    console.log('카테고리별 카운트 계산 시작...');
    
    // 각 섹션에서 카테고리별 아이템 카운트
    ['PASS', 'FAIL', 'MANUAL'].forEach(status => {
        const items = getAllItemsFromSection(status);
        console.log(`${status} 섹션에서 ${items.length}개 아이템 발견`);
        
        items.forEach((item, index) => {
            const categoryTag = item.querySelector('.category-tag');
            if (categoryTag) {
                // 아이콘을 제외한 텍스트만 안전하게 추출
                const categoryText = extractCategoryText(categoryTag);
                const koreanCategory = categoryMapping[categoryText] || categoryText;
                
                console.log(`${status}[${index}] 카테고리: "${categoryText}" -> "${koreanCategory}"`);
                
                // 카테고리가 없으면 동적으로 추가
                if (!categoryCounts[koreanCategory]) {
                    console.log(`새 카테고리 "${koreanCategory}" 추가`);
                    categoryCounts[koreanCategory] = { pass: 0, fail: 0, manual: 0, total: 0 };
                }
                
                if (status === 'PASS') {
                    categoryCounts[koreanCategory].pass++;
                } else if (status === 'FAIL') {
                    categoryCounts[koreanCategory].fail++;
                } else if (status === 'MANUAL') {
                    categoryCounts[koreanCategory].manual++;
                }
                categoryCounts[koreanCategory].total++;
            } else {
                console.warn(`${status}[${index}] 아이템에서 카테고리 태그를 찾을 수 없음`);
            }
        });
    });
    
    // 최종 결과 로그 출력
    console.log('카테고리별 최종 카운트:');
    Object.keys(categoryCounts).forEach(cat => {
        const counts = categoryCounts[cat];
        console.log(`  ${cat}: Pass=${counts.pass}, Fail=${counts.fail}, Manual=${counts.manual}, Total=${counts.total}`);
    });
    
    return categoryCounts;
}

// 카테고리 태그에서 텍스트를 안전하게 추출하는 함수
function extractCategoryText(categoryTag) {
    // 방법 1: textContent에서 아이콘 문자 제거
    let categoryText = categoryTag.textContent.trim();
    
    // 방법 2: 만약 위 방법이 실패하면 innerHTML에서 추출
    if (!categoryText) {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = categoryTag.innerHTML;
        // 아이콘 태그 제거
        const icons = tempDiv.querySelectorAll('i');
        icons.forEach(icon => icon.remove());
        categoryText = tempDiv.textContent.trim();
    }
    
    console.log(`카테고리 텍스트 추출: "${categoryTag.innerHTML}" -> "${categoryText}"`);
    return categoryText;
}

// 특정 섹션에서 모든 아이템을 가져오는 함수 (새로운 카테고리별 구조용)
function getAllItemsFromSection(status) {
    // 새로운 카테고리별 구조에서 특정 상태의 모든 아이템 가져오기
    const items = [];
    
    const categorySections = document.querySelectorAll('#category-by-type-container .category-section');
    categorySections.forEach(categorySection => {
        const subSections = categorySection.querySelectorAll('.status-subsection');
        subSections.forEach(subSection => {
            const subTitle = subSection.querySelector('.sub-category-title');
            if (subTitle) {
                let isTargetStatus = false;
                if (status === 'PASS' && subTitle.textContent.includes('조치 완료')) {
                    isTargetStatus = true;
                } else if (status === 'FAIL' && subTitle.textContent.includes('조치 필요')) {
                    isTargetStatus = true;
                } else if (status === 'MANUAL' && subTitle.textContent.includes('점검 필요')) {
                    isTargetStatus = true;
                }
                
                if (isTargetStatus) {
                    const subItems = subSection.querySelectorAll('.check-item');
                    items.push(...subItems);
                }
            }
        });
    });
    
    return items;
}

// 상태별 아이템 개수를 안전하게 계산하는 함수 (새로운 구조용)
function getItemCountByCategory(status) {
    try {
        console.log(`${status} 상태의 아이템 개수 계산 중...`);
        
        // 새로운 카테고리별 구조에서 특정 상태의 모든 아이템 개수 계산
        const items = getAllItemsFromSection(status);
        let count = items.length;
        
        // 새로운 구조에서 찾지 못했다면 원본 섹션에서 시도 (fallback)
        if (count === 0) {
            console.log(`새로운 구조에서 ${status} 항목을 찾을 수 없어 원본 섹션에서 시도...`);
            const originalItems = document.querySelectorAll(`#original-sections [data-status="${status}"]`);
            count = originalItems.length;
            console.log(`원본 섹션에서 ${status} 상태에 ${count}개 항목 발견`);
        }
        
        console.log(`${status} 상태에 ${count}개 항목 발견`);
        return count;
    } catch (error) {
        console.error(`상태 ${status} 카운트 계산 중 오류:`, error);
        return 0;
    }
}

// 카테고리 헤더 카운트 업데이트
function updateCategoryHeaderCount(category, count) {
    const categoryTitle = document.querySelector(`[data-category="${category}"] h3`);
    if (categoryTitle) {
        const categoryName = getCategoryDisplayName(category);
        // categoryTitle.innerHTML = `
        //     <span class="category-icon ${getCategoryIconClass(category)}">
        //         <i class="bi ${getCategoryIcon(category)}"></i>
        //     </span>
        //     ${categoryName} (${count})
        // `;
        if (category === 'PASS') {
            categoryTitle.innerHTML = `
                <i class="category-icon success-bg"><img src="./images/ico-pass.svg" alt="${categoryName}"></i>
                ${categoryName} <span>(${count})</span>
            `;
        } else if (category === 'FAIL') {
            categoryTitle.innerHTML = `
                <i class="category-icon danger-bg"><img src="./images/ico-failure.svg" alt="${categoryName}"></i>
                ${categoryName} <span>(${count})</span>
            `;
        } else if (category === 'MANUAL') {
            categoryTitle.innerHTML = `
                <i class="category-icon warning-bg"><img src="./images/ico-inspection.svg" alt="${categoryName}"></i>
                ${categoryName} <span>(${count})</span>
            `;
        }
    }
}

// 상단 요약 카운트 업데이트
function updateSummaryCount(type, count) {
    console.log(`요약 카운트 업데이트: ${type} = ${count}`);
    
    // 기존 원형 카운트 업데이트 (하위 호환성을 위해 유지)
    const countCircles = document.querySelectorAll('.count-circle');
    console.log(`총 ${countCircles.length}개의 count-circle 발견`);
    
    let targetIndex = -1;
    
    switch(type) {
        case 'pass':
            targetIndex = 0;
            break;
        case 'fail':
            targetIndex = 1;
            break;
        case 'check':
            targetIndex = 2;
            break;
    }
    
    if (targetIndex !== -1 && countCircles[targetIndex]) {
        const oldValue = countCircles[targetIndex].textContent;
        countCircles[targetIndex].textContent = count;
        console.log(`${type} 카운트 업데이트: ${oldValue} → ${count}`);
    } else {
        console.error(`${type} 카운트 업데이트 실패: targetIndex=${targetIndex}, 요소 존재=${!!countCircles[targetIndex]}`);
    }
    
    // 새로운 카드 숫자 업데이트
    updateSummaryCards(type, count);
}

// 새로운 summary 카드들의 숫자 업데이트 함수
function updateSummaryCards(type, count) {
    let cardElementId = '';
    
    switch(type) {
        case 'pass':
            cardElementId = 'passCardNumber';
            break;
        case 'fail':
            cardElementId = 'failCardNumber';
            break;
        case 'check':
            cardElementId = 'manualCardNumber';
            break;
    }
    
    if (cardElementId) {
        const cardElement = document.getElementById(cardElementId);
        if (cardElement) {
            const oldValue = cardElement.textContent;
            cardElement.textContent = count;
            console.log(`${type} 카드 숫자 업데이트: ${oldValue} → ${count}`);
        } else {
            console.error(`카드 요소 ${cardElementId}를 찾을 수 없습니다.`);
        }
    }
}

// 카테고리 표시 이름 반환
function getCategoryDisplayName(category) {
    switch(category) {
        case 'PASS':
            return '조치 완료';
        case 'FAIL':
            return '조치 필요';
        case 'MANUAL':
            return '점검 필요';
        default:
            return category;
    }
}

// 카테고리 아이콘 클래스 반환
function getCategoryIconClass(category) {
    switch(category) {
        case 'PASS':
            return 'success-bg';
        case 'FAIL':
            return 'danger-bg';
        case 'MANUAL':
            return 'warning-bg';
        default:
            return '';
    }
}

// 카테고리 아이콘 반환
function getCategoryIcon(category) {
    switch(category) {
        case 'PASS':
            return 'bi-check-circle';
        case 'FAIL':
            return 'bi-x-circle';
        case 'MANUAL':
            return 'bi-exclamation-triangle';
        default:
            return 'bi-circle';
    }
}

// 성공 메시지 표시 함수
function showSuccessMessage(checkName) {
    // 간단한 토스트 메시지 생성
    const toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.innerHTML = `
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle me-2"></i>
            <strong>${checkName}</strong> 항목이 완료 처리되었습니다.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    // 페이지 상단에 추가
    document.body.prepend(toast);
    
    // 3초 후 자동 제거
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// 점수 계산 및 표시 함수 (새로운 방식: 모든 항목 대비 통과 비율)
function calculateAndDisplayScore() {
    try {
        console.log('=== 점수 계산 시작 (새로운 방식) ===');
        
        // 현재 카운트 직접 계산 - 안전한 방법 사용
        let passCount = getItemCountByCategory('PASS');
        let failCount = getItemCountByCategory('FAIL');
        let manualCount = getItemCountByCategory('MANUAL');
        
        console.log(`DOM에서 계산된 카운트: Pass=${passCount}, Fail=${failCount}, Manual=${manualCount}`);
        
        // 만약 모든 카운트가 0이라면, 초기 상태에서 HTML 템플릿 값 사용
        if (passCount === 0 && failCount === 0 && manualCount === 0) {
            console.log('DOM에서 항목을 찾을 수 없어 초기 값을 사용합니다.');
            const statsElements = document.querySelectorAll('.count-circle');
            console.log(`count-circle 요소 개수: ${statsElements.length}`);
            
            if (statsElements.length >= 3) {
                passCount = parseInt(statsElements[0].textContent) || 0;
                failCount = parseInt(statsElements[1].textContent) || 0;
                manualCount = parseInt(statsElements[2].textContent) || 0;
                console.log(`초기 값: Pass=${passCount}, Fail=${failCount}, Manual=${manualCount}`);
            } else {
                console.error('count-circle 요소를 충분히 찾을 수 없습니다.');
            }
        }
        
        // 새로운 점수 계산 방식: 모든 항목 (Pass + Fail + Manual) 대비 Pass 비율
        const totalCount = passCount + failCount + manualCount;
        console.log(`전체 항목 수: Pass=${passCount} + Fail=${failCount} + Manual=${manualCount} = ${totalCount}`);
        
        if (totalCount === 0) {
            console.log('전체 항목 수가 0입니다.');
            updateScoreDisplay(0, '평가 불가');
            updateScoreCircle(0, 0, 0, '평가 불가');
            return;
        }
        
        // 각 항목의 비율 계산
        const passPercentage = Math.round((passCount * 100) / totalCount);
        const failPercentage = Math.round((failCount * 100) / totalCount);
        const manualPercentage = Math.round((manualCount * 100) / totalCount);
        
        // 반올림으로 인한 오차 조정
        let adjustedPassPercentage = passPercentage;
        let adjustedFailPercentage = failPercentage;
        let adjustedManualPercentage = manualPercentage;
        
        const sum = adjustedPassPercentage + adjustedFailPercentage + adjustedManualPercentage;
        if (sum !== 100 && totalCount > 0) {
            // 가장 큰 비율에 차이만큼 조정
            const diff = 100 - sum;
            if (adjustedPassPercentage >= adjustedFailPercentage && adjustedPassPercentage >= adjustedManualPercentage) {
                adjustedPassPercentage += diff;
            } else if (adjustedFailPercentage >= adjustedManualPercentage) {
                adjustedFailPercentage += diff;
            } else {
                adjustedManualPercentage += diff;
            }
        }
        
        // 점수는 통과 비율로 설정
        const score = adjustedPassPercentage;
        
        // 점수에 따른 라벨 설정
        let label = '';
        if (score >= 80) {
            label = '우수';
        } else if (score >= 60) {
            label = '양호';
        } else if (score >= 40) {
            label = '주의';
        } else {
            label = '위험';
        }
        
        console.log(`계산된 비율:`);
        console.log(`  - Pass: ${adjustedPassPercentage}% (${passCount}/${totalCount})`);
        console.log(`  - Fail: ${adjustedFailPercentage}% (${failCount}/${totalCount})`);
        console.log(`  - Manual: ${adjustedManualPercentage}% (${manualCount}/${totalCount})`);
        console.log(`  - 총합: ${adjustedPassPercentage + adjustedFailPercentage + adjustedManualPercentage}%`);
        console.log(`최종 점수: ${score} (${label})`);
        
        // 점수 표시 업데이트 (% 포함)
        updateScoreDisplay(score, label);
        
        // 3색 원형 차트 업데이트
        updateScoreCircle(adjustedPassPercentage, adjustedFailPercentage, adjustedManualPercentage, label);
        
        console.log(`=== 점수 계산 완료: ${score} (${label}) ===`);
        
    } catch (error) {
        console.error('점수 계산 중 오류 발생:', error);
        updateScoreDisplay(0, '오류');
        updateScoreCircle(0, 0, 0, '오류');
    }
}

// 점수 표시 업데이트 함수 (% 포함)
function updateScoreDisplay(score, label) {
    console.log(`점수 표시 업데이트 시도: ${score}, ${label}`);
    
    const scoreValueElement = document.getElementById('scoreValue');
    const scoreLabelElement = document.getElementById('scoreLabel');
    
    if (scoreValueElement) {
        const oldScore = scoreValueElement.textContent;
        // % 단위 추가
        scoreValueElement.textContent = score === 0 && label === '평가 불가' ? '-' : `${score}`;
        console.log(`점수 값 업데이트: ${oldScore} → ${score}`);
    } else {
        console.error('scoreValue 요소를 찾을 수 없습니다.');
    }
    
    if (scoreLabelElement) {
        const oldLabel = scoreLabelElement.textContent;
        scoreLabelElement.textContent = label;
        console.log(`점수 라벨 업데이트: ${oldLabel} → ${label}`);
    } else {
        console.error('scoreLabel 요소를 찾을 수 없습니다.');
    }
}

// 3색 원형 차트 업데이트 함수 (초록색: Pass, 노란색: Manual, 빨간색: Fail)
function updateScoreCircle(passPercentage, failPercentage, manualPercentage, label) {
    console.log(`3색 원형 차트 업데이트 시도: Pass=${passPercentage}%, Manual=${manualPercentage}%, Fail=${failPercentage}%, Label=${label}`);
    
    const scoreCircle = document.getElementById('scoreCircle');
    
    if (!scoreCircle) {
        console.error('scoreCircle 요소를 찾을 수 없습니다.');
        return;
    }
    
    // 총합이 0이면 회색으로 표시
    const totalPercentage = passPercentage + failPercentage + manualPercentage;
    if (totalPercentage === 0) {
        scoreCircle.style.background = 'conic-gradient(#e5e7eb 0deg 360deg)';
        console.log('총 비율이 0%이므로 회색으로 표시');
        return;
    }
    
    // 각 구간의 각도 계산 (360도 기준)
    const passAngle = (passPercentage / 100) * 360;
    const manualAngle = (manualPercentage / 100) * 360;
    const failAngle = (failPercentage / 100) * 360;
    
    console.log(`각도 계산: Pass=${passAngle}°, Manual=${manualAngle}°, Fail=${failAngle}°`);
    
    // 색상 정의
    const passColor = '#10B981';   // 초록색
    const manualColor = '#F6A61F'; // 노란색  
    const failColor = '#EF4242';   // 빨간색
    const emptyColor = '#e5e7eb';  // 회색 (빈 공간)
    
    // conic-gradient 구성
    let gradientSegments = [];
    let currentAngle = 0;
    
    // Pass 구간 (초록색)
    if (passPercentage > 0) {
        const startAngle = currentAngle;
        const endAngle = currentAngle + passAngle;
        gradientSegments.push(`${passColor} ${startAngle}deg ${endAngle}deg`);
        currentAngle = endAngle;
        console.log(`Pass 구간: ${startAngle}° ~ ${endAngle}°`);
    }
    
    // Manual 구간 (노란색)
    if (manualPercentage > 0) {
        const startAngle = currentAngle;
        const endAngle = currentAngle + manualAngle;
        gradientSegments.push(`${manualColor} ${startAngle}deg ${endAngle}deg`);
        currentAngle = endAngle;
        console.log(`Manual 구간: ${startAngle}° ~ ${endAngle}°`);
    }
    
    // Fail 구간 (빨간색)
    if (failPercentage > 0) {
        const startAngle = currentAngle;
        const endAngle = currentAngle + failAngle;
        gradientSegments.push(`${failColor} ${startAngle}deg ${endAngle}deg`);
        currentAngle = endAngle;
        console.log(`Fail 구간: ${startAngle}° ~ ${endAngle}°`);
    }
    
    // 남은 공간이 있으면 회색으로 채움
    if (currentAngle < 360) {
        gradientSegments.push(`${emptyColor} ${currentAngle}deg 360deg`);
        console.log(`빈 공간: ${currentAngle}° ~ 360°`);
    }
    
    // conic-gradient 문자열 생성
    const backgroundStyle = `conic-gradient(${gradientSegments.join(', ')})`;
    scoreCircle.style.background = backgroundStyle;
    console.log(`3색 원형 차트 배경 업데이트: ${backgroundStyle}`);
    
    // 점수 라벨에 색상 클래스 추가 (Pass 비율 기준)
    const scoreLabelElement = document.getElementById('scoreLabel');
    if (scoreLabelElement) {
        // 기존 클래스 제거
        scoreLabelElement.classList.remove('text-success', 'text-info', 'text-warning', 'text-danger', 'text-muted');
        
        // Pass 비율에 따른 색상 클래스 추가
        let colorClass = '';
        if (passPercentage >= 80) {
            colorClass = 'text-success'; // 초록색
        } else if (passPercentage >= 60) {
            colorClass = 'text-info';    // 파란색
        } else if (passPercentage >= 40) {
            colorClass = 'text-warning'; // 노란색
        } else if (passPercentage > 0) {
            colorClass = 'text-danger';  // 빨간색
        } else {
            colorClass = 'text-muted';   // 회색
        }
        
        if (colorClass) {
            scoreLabelElement.classList.add(colorClass);
            console.log(`점수 라벨 색상 클래스 추가: ${colorClass} (Pass: ${passPercentage}%)`);
        }
    } else {
        console.warn('scoreLabel 요소를 찾을 수 없어 색상 클래스를 적용할 수 없습니다.');
    }
}

// 트렌드 차트 초기화
function initTrendChart() {
    const ctx = document.getElementById('trendChart');
    
    if (ctx) {
        const trendChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['05월 01일', '05월 11일', '05월 18일'],
                datasets: [{
                    label: '점수',
                    data: [15, 23, 37],
                    fill: false,
                    borderColor: '#3b82f6',
                    tension: 0.1,
                    pointBackgroundColor: '#3b82f6',
                    pointRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            stepSize: 20,
                            font: {
                                size: window.innerWidth < 768 ? 10 : 12
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            font: {
                                size: window.innerWidth < 768 ? 9 : 11
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleFont: {
                            size: window.innerWidth < 768 ? 12 : 14
                        },
                        bodyFont: {
                            size: window.innerWidth < 768 ? 11 : 13
                        }
                    }
                }
            }
        });
        
        // 차트 인스턴스를 전역으로 저장하여 리사이즈 시 업데이트 가능
        window.trendChartInstance = trendChart;
    }
}

// 카테고리 토글 기능 초기화 (새로운 구조용)
function initCategoryToggles() {
    // 새로운 카테고리별 구조의 토글 기능은 createCategorySection에서 이미 설정됨
    // 여기서는 추가 토글 기능이 필요하면 구현
    console.log('카테고리 토글 기능 초기화 완료 (새로운 구조)');
}

// 모든 카테고리 접기/펼치기 버튼 초기화 (새로운 구조용)
function initToggleAllButton() {
    const toggleAllBtn = document.getElementById('toggle-all-btn');
    
    if (!toggleAllBtn) return;
    
    // 정적 상태 관리 - 초기에는 모든 카테고리가 열려있으므로 "접기"부터 시작
    let allExpanded = true; // 초기 상태: 접기 버튼 표시
    
    function updateButtonText(isExpanded) {
        toggleAllBtn.innerHTML = isExpanded ? 
            '<i class="bi bi-arrows-collapse"></i> 모든 카테고리 접기' : 
            '<i class="bi bi-arrows-expand"></i> 모든 카테고리 펼치기';
    }
    
    // 초기 버튼 텍스트 설정 - "모든 카테고리 접기"로 시작
    updateButtonText(true);
    
    // 클릭 이벤트 리스너 추가
    toggleAllBtn.addEventListener('click', function(e) {
        e.preventDefault();
        
        // 새로운 카테고리별 구조에서 카테고리 섹션들 찾기
        const categorySections = document.querySelectorAll('#category-by-type-container .category-section');
        
        if (allExpanded) {
            // 모든 카테고리 접기
            categorySections.forEach(section => {
                const title = section.querySelector('.category-title');
                const content = section.querySelector('.category-content');
                
                if (content) content.style.display = "none";
                if (title) title.classList.remove('active');
            });
            allExpanded = false;
            updateButtonText(false);
        } else {
            // 모든 카테고리 펼치기
            categorySections.forEach(section => {
                const title = section.querySelector('.category-title');
                const content = section.querySelector('.category-content');
                
                if (content) content.style.display = "block";
                if (title) title.classList.add('active');
            });
            allExpanded = true;
            updateButtonText(true);
        }
    });
}

// 보고서 다운로드(인쇄) 기능
function initDownloadButton() {
    const downloadBtn = document.querySelector('.download-btn');
    
    if (downloadBtn) {
        downloadBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            console.log('보고서 인쇄 시작...');
            
            // 인쇄 전 UI 준비
            prepareForPrint();
            
            // 약간의 지연 후 인쇄 (UI 준비 완료 대기)
            setTimeout(() => {
                window.print();
                console.log('인쇄 대화상자 열림');
            }, 500);
        });
        
        console.log('다운로드 버튼 이벤트 리스너 등록 완료');
    } else {
        console.error('다운로드 버튼을 찾을 수 없습니다.');
    }
}

// 인쇄를 위한 UI 준비 함수
function prepareForPrint() {
    console.log('인쇄 대화상자 열기...');
    // 별도의 스타일 변경 없이 그대로 인쇄
}

// 반응형 기능 초기화
function initResponsiveFeatures() {
    // 화면 크기에 따른 초기 설정
    updateLayoutForScreenSize();
    
    // 긴 리소스 아이템 처리
    handleLongResourceItems();
    
    // 스크롤 위치 저장/복원
    handleScrollPosition();
}

// 화면 크기에 따른 레이아웃 업데이트
function updateLayoutForScreenSize() {
    const isMobile = window.innerWidth < 768;
    const isTablet = window.innerWidth >= 768 && window.innerWidth < 992;
    
    // 모바일에서 카테고리 박스 간격 조정
    const categoryBoxes = document.querySelectorAll('.category-box');
    categoryBoxes.forEach(box => {
        if (isMobile) {
            box.style.marginBottom = '1rem';
        } else {
            box.style.marginBottom = '1.5rem';
        }
    });
    
    // 체크 아이템 간격 조정
    const checkItems = document.querySelectorAll('.check-item');
    checkItems.forEach(item => {
        if (isMobile) {
            item.style.marginBottom = '0.75rem';
        } else {
            item.style.marginBottom = '1rem';
        }
    });
}

// 긴 리소스 아이템 처리
function handleLongResourceItems() {
    const resourceItems = document.querySelectorAll('.resource-item');
    
    resourceItems.forEach(item => {
        // 텍스트가 너무 긴 경우 말줄임표 추가 옵션
        if (item.textContent.length > 100 && window.innerWidth < 576) {
            item.setAttribute('title', item.textContent);
            item.style.overflow = 'hidden';
            item.style.textOverflow = 'ellipsis';
            item.style.whiteSpace = 'nowrap';
            
            // 클릭하면 전체 텍스트 보기
            item.style.cursor = 'pointer';
            item.addEventListener('click', function() {
                if (this.style.whiteSpace === 'nowrap') {
                    this.style.whiteSpace = 'normal';
                    this.style.textOverflow = 'initial';
                } else {
                    this.style.whiteSpace = 'nowrap';
                    this.style.textOverflow = 'ellipsis';
                }
            });
        }
    });
}

// 스크롤 위치 관리
function handleScrollPosition() {
    // 페이지 새로고침 시 스크롤 위치 복원
    const savedScrollPosition = sessionStorage.getItem('reportScrollPosition');
    if (savedScrollPosition) {
        window.scrollTo(0, parseInt(savedScrollPosition));
        sessionStorage.removeItem('reportScrollPosition');
    }
    
    // 페이지 떠날 때 스크롤 위치 저장
    window.addEventListener('beforeunload', function() {
        sessionStorage.setItem('reportScrollPosition', window.scrollY);
    });
}

// 모바일 최적화
function initMobileOptimizations() {
    if ('ontouchstart' in window) {
        // 터치 디바이스에서 호버 효과 제거
        document.body.classList.add('touch-device');
        
        // 더블 탭 줌 방지 (필요시)
        let lastTouchEnd = 0;
        document.addEventListener('touchend', function (event) {
            const now = (new Date()).getTime();
            if (now - lastTouchEnd <= 300) {
                event.preventDefault();
            }
            lastTouchEnd = now;
        }, false);
        
        // 터치 스크롤 최적화
        document.addEventListener('touchstart', function(e) {
            if (e.touches.length > 1) {
                e.preventDefault();
            }
        }, { passive: false });
    }
    
    // 키보드 나타날 때 레이아웃 조정 (iOS Safari)
    if (/iPad|iPhone|iPod/.test(navigator.userAgent)) {
        const viewport = document.querySelector('meta[name=viewport]');
        if (viewport) {
            viewport.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
        }
    }
}

// 리사이즈 이벤트 처리
function initResizeHandler() {
    let resizeTimer;
    
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function() {
            // 레이아웃 업데이트
            updateLayoutForScreenSize();
            
            // 차트 업데이트
            if (window.trendChartInstance) {
                const isMobile = window.innerWidth < 768;
                window.trendChartInstance.options.scales.y.ticks.font.size = isMobile ? 10 : 12;
                window.trendChartInstance.options.scales.x.ticks.font.size = isMobile ? 9 : 11;
                window.trendChartInstance.options.plugins.tooltip.titleFont.size = isMobile ? 12 : 14;
                window.trendChartInstance.options.plugins.tooltip.bodyFont.size = isMobile ? 11 : 13;
                window.trendChartInstance.update();
            }
            
            // 긴 리소스 아이템 재처리
            handleLongResourceItems();
            
        }, 250);
    });
}



// 스크롤 시 헤더 효과 (선택사항)
function initScrollEffects() {
    const header = document.querySelector('.main-header');
    let lastScrollTop = 0;
    
    window.addEventListener('scroll', function() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        if (scrollTop > lastScrollTop && scrollTop > 100) {
            // 스크롤 다운
            header.style.transform = 'translateY(-100%)';
        } else {
            // 스크롤 업
            header.style.transform = 'translateY(0)';
        }
        
        lastScrollTop = scrollTop;
    });
}

// 접근성 향상
function initAccessibilityFeatures() {
    // 키보드 내비게이션 지원
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ') {
            const activeElement = document.activeElement;
            
            if (activeElement.classList.contains('category-title')) {
                e.preventDefault();
                activeElement.click();
            }
            

        }
    });
    
    // 포커스 관리
    const focusableElements = document.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    
    focusableElements.forEach(element => {
        element.addEventListener('focus', function() {
            this.style.outline = '2px solid #3b82f6';
            this.style.outlineOffset = '2px';
        });
        
        element.addEventListener('blur', function() {
            this.style.outline = 'none';
        });
    });
}

// 필요시 추가 기능 활성화
// initScrollEffects();
// initAccessibilityFeatures();

// 카테고리 박스 클릭 스크롤 기능 초기화
function initCategoryBoxScrolling() {
    const categoryBoxes = document.querySelectorAll('.category-box');
    
    categoryBoxes.forEach(box => {
        // 각 카테고리 박스에 클릭 이벤트 리스너 추가
        box.addEventListener('click', function(e) {
            e.preventDefault();
            
            // 카테고리 이름 추출
            const categoryTitle = this.querySelector('h3').textContent.trim();
            console.log(`카테고리 박스 클릭됨: ${categoryTitle}`);
            
            // 해당 카테고리 상세 섹션으로 스크롤
            scrollToCategorySection(categoryTitle);
        });
        
        // 클릭 가능함을 나타내는 스타일 추가
        box.style.cursor = 'pointer';
        
        // 호버 효과 향상
        box.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
            this.style.boxShadow = '0 8px 16px rgba(0,0,0,0.15)';
        });
        
        box.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(-3px)';
            this.style.boxShadow = '0 6px 12px rgba(0,0,0,0.1)';
        });
    });
    
    console.log(`${categoryBoxes.length}개의 카테고리 박스에 클릭 이벤트 리스너 추가 완료`);
}

// 특정 카테고리 섹션으로 스크롤하는 함수
function scrollToCategorySection(categoryName) {
    // 카테고리별로 재구성된 섹션에서 해당 카테고리 찾기
    const categorySections = document.querySelectorAll('#category-by-type-container .category-section');
    
    let targetSection = null;
    
    categorySections.forEach(section => {
        const categoryTitle = section.querySelector('.category-title h3');
        if (categoryTitle) {
            const titleText = categoryTitle.textContent.trim();
            // 카테고리 이름이 포함되어 있는지 확인 (카운트 포함)
            if (titleText.includes(categoryName)) {
                targetSection = section;
                console.log(`타겟 섹션 찾음: ${titleText}`);
            }
        }
    });
    
    if (targetSection) {
        // 스크롤 위치 계산 (헤더 높이를 고려하여 약간 위로)
        const headerHeight = document.querySelector('.main-header').offsetHeight || 0;
        const sectionTop = targetSection.offsetTop;
        const scrollPosition = sectionTop - headerHeight - 20; // 20px 여백 추가
        
        console.log(`스크롤 위치: ${scrollPosition} (섹션 위치: ${sectionTop}, 헤더 높이: ${headerHeight})`);
        
        // 부드러운 스크롤
        window.scrollTo({
            top: scrollPosition,
            behavior: 'smooth'
        });
        
        // 카테고리가 접혀있다면 펼치기
        expandCategorySection(targetSection);
        
        // 시각적 강조 효과 (선택사항)
        highlightCategorySection(targetSection);
        
    } else {
        console.warn(`카테고리 "${categoryName}"에 해당하는 섹션을 찾을 수 없습니다.`);
        
        // 디버깅을 위해 사용 가능한 카테고리들 출력
        const availableCategories = [];
        categorySections.forEach(section => {
            const title = section.querySelector('.category-title h3');
            if (title) {
                availableCategories.push(title.textContent.trim());
            }
        });
        console.log('사용 가능한 카테고리들:', availableCategories);
    }
}

// 카테고리 섹션을 펼치는 함수
function expandCategorySection(categorySection) {
    const categoryTitle = categorySection.querySelector('.category-title');
    const categoryContent = categorySection.querySelector('.category-content');
    
    if (categoryTitle && categoryContent) {
        // 섹션이 접혀있다면 펼치기
        if (categoryContent.style.display === 'none') {
            categoryContent.style.display = 'block';
            categoryTitle.classList.add('active');
            console.log('카테고리 섹션을 펼쳤습니다.');
        }
    }
}

// 카테고리 섹션을 시각적으로 강조하는 함수
function highlightCategorySection(categorySection) {
    // 기존 강조 효과 제거
    const previousHighlighted = document.querySelector('.category-section.highlighted');
    if (previousHighlighted) {
        previousHighlighted.classList.remove('highlighted');
    }
    
    // 새로운 강조 효과 추가
    categorySection.classList.add('highlighted');
    
    // 3초 후 강조 효과 제거
    setTimeout(() => {
        categorySection.classList.remove('highlighted');
    }, 3000);
} 

// ============================================
// LocalStorage 관련 함수들
// ============================================

// localStorage 키 상수
const MANUAL_CHECK_STORAGE_KEY = 'eks-checklist-manual-checks';

// 수동 점검 체크 상태를 localStorage에 저장
function saveManualCheckState(checkName, isChecked, extra = {}) {
    try {
        // 기존 저장된 상태 가져오기
        const savedStates = getManualCheckStates();
        
        // 상태 업데이트
        if (isChecked) {
            // 체크 시 더 자세한 정보 저장
            const manualItem = document.querySelector(`[data-check-name="${checkName}"]`);
            const category = manualItem ? manualItem.dataset.category : "Unknown";
            const categoryName = manualItem ? manualItem.dataset.categoryName : "Unknown";
            // 이유/런북 추출 (인자로 우선권)
            let reasonHTML = extra.reasonHTML;
            let runbookHref = extra.runbookHref;
            if (!reasonHTML || !runbookHref || !extra.resourceHTML) {
                const reasonElement = manualItem ? manualItem.querySelector('.check-reason') : null;
                const runbookLink = manualItem ? manualItem.querySelector('.runbook-link') : null;
                const resourceContainer = manualItem ? manualItem.querySelector('.mb-3') : null;
                reasonHTML = reasonHTML || (reasonElement ? reasonElement.innerHTML : '');
                runbookHref = runbookHref || (runbookLink ? runbookLink.getAttribute('href') : '');
                extra.resourceHTML = extra.resourceHTML || (resourceContainer ? resourceContainer.innerHTML : '');
            }
            
            savedStates[checkName] = {
                checked: true,
                timestamp: new Date().toISOString(),
                category: category,
                categoryName: categoryName,
                url: window.location.href,
                reasonHTML: reasonHTML || '',
                runbookHref: runbookHref || '',
                resourceHTML: extra.resourceHTML || ''
            };
        } else {
            // 체크 해제 시 상태를 보존하되 checked만 false로
            const existing = savedStates[checkName] || {};
            savedStates[checkName] = {
                ...existing,
                checked: false,
                timestamp: new Date().toISOString(),
                reasonHTML: (extra && extra.reasonHTML) || existing.reasonHTML || '',
                runbookHref: (extra && extra.runbookHref) || existing.runbookHref || '',
                resourceHTML: (extra && extra.resourceHTML) || existing.resourceHTML || ''
            };
        }
        
        // localStorage에 저장
        localStorage.setItem(MANUAL_CHECK_STORAGE_KEY, JSON.stringify(savedStates));
        console.log(`수동 점검 상태 저장: ${checkName} = ${isChecked}`);
        
    } catch (error) {
        console.error('수동 점검 상태 저장 중 오류:', error);
    }
}

// localStorage에서 모든 수동 점검 상태 가져오기
function getManualCheckStates() {
    try {
        const savedData = localStorage.getItem(MANUAL_CHECK_STORAGE_KEY);
        return savedData ? JSON.parse(savedData) : {};
    } catch (error) {
        console.error('수동 점검 상태 로드 중 오류:', error);
        return {};
    }
}

// 특정 항목의 체크 상태 확인
function isManualCheckSaved(checkName) {
    const savedStates = getManualCheckStates();
    return savedStates[checkName] && savedStates[checkName].checked === true;
}

// localStorage에서 체크 상태 복원
function restoreManualCheckStates() {
    console.log('localStorage에서 수동 점검 상태 복원 시작...');
    
    const savedStates = getManualCheckStates();
    const savedCheckNames = Object.keys(savedStates);
    
    console.log(`복원할 체크 항목 수: ${savedCheckNames.length}`, savedCheckNames);
    
    // 카테고리별 체크리스트 재구성을 먼저 수행
    if (savedCheckNames.length === 0) {
        console.log('저장된 체크 상태가 없습니다. 기본 카테고리별 재구성만 진행합니다.');
        reorganizeChecklistByCategory();
        return;
    }
    
    console.log('체크된 항목이 있습니다. 복원 과정을 시작합니다.');
    
    // 복원하기 전에 원본 섹션에서 체크된 항목들을 미리 제거
    savedCheckNames.forEach(checkName => {
        const state = savedStates[checkName];
        if (state.checked) {
            // 원본 섹션에서 해당 항목 찾아서 제거
            const originalManualItem = document.querySelector(`#original-sections .manual-item[data-check-name="${checkName}"]`);
            if (originalManualItem) {
                originalManualItem.remove();
                console.log(`📤 원본 섹션에서 체크된 항목 제거: ${checkName}`);
            }
        }
    });
    
    // 카테고리별 체크리스트 재구성 (체크된 항목들이 제거된 상태로)
    console.log('🔄 체크된 항목 제거 후 카테고리별 재구성 시작...');
    reorganizeChecklistByCategory();
    
    // 각 저장된 체크 항목에 대해 복원 처리
    savedCheckNames.forEach(checkName => {
        const state = savedStates[checkName];
        if (state.checked) {
            restoreSingleManualCheck(checkName);
        }
    });
    
    // 상태 복원 후 카운트 업데이트
    setTimeout(() => {
        updateCategoryCounts();
        calculateAndDisplayScore();
        updateCategoryBoxCounts();
        console.log('수동 점검 상태 복원 완료 및 카운트 업데이트');
    }, 100);
}

// 개별 수동 점검 항목 복원
function restoreSingleManualCheck(checkName) {
    console.log(`수동 점검 항목 복원 중: ${checkName}`);
    
    // 저장된 상태에서 정보 먼저 확인
    const savedStates = getManualCheckStates();
    const savedState = savedStates[checkName];
    
    let category = "Unknown";
    let categoryName = "General Check"; // 기본값
    
    // 저장된 카테고리 정보가 있으면 우선 사용
    if (savedState && savedState.category && savedState.categoryName) {
        category = savedState.category;
        categoryName = savedState.categoryName;
        console.log(`저장된 카테고리 정보 사용: ${category} / ${categoryName}`);
    } else {
        console.log(`저장된 카테고리 정보가 없어 추정 시도: ${checkName}`);
    
    // checkName을 통해 카테고리 추정 - 실제 체크 항목 이름 기반 매핑
    if (checkName.includes("API 엔드포인트") || checkName.includes("클러스터 접근 제어") || checkName.includes("IRSA") || checkName.includes("Pod Identity") || checkName.includes("IAM") || checkName.includes("루트 유저") || checkName.includes("멀티 태넌시") || checkName.includes("Audit 로그") || checkName.includes("EBS 볼륨 암호화") || checkName.includes("네트워크 정책")) {
        category = "Security Check";
        categoryName = "Security Check";
    } else if (checkName.includes("Karpenter") || checkName.includes("HPA") || checkName.includes("VPA") || checkName.includes("Cluster Autoscaler")) {
        category = "Scalability Check";  
        categoryName = "Scalability Check";
    } else if (checkName.includes("백업") || checkName.includes("모니터링") || checkName.includes("로깅") || checkName.includes("복구") || checkName.includes("안정성") || checkName.includes("재해복구")) {
        category = "Stability Check";
        categoryName = "Stability Check";
    } else if (checkName.includes("CNI") || checkName.includes("DNS") || checkName.includes("kube-proxy") || checkName.includes("IPVS") || checkName.includes("EndpointSlices") || checkName.includes("네트워크")) {
        category = "Network Check";
        categoryName = "Network Check";
    } else if (checkName.includes("Kubecost") || checkName.includes("비용")) {
        category = "Cost-Optimized Check";
        categoryName = "Cost-Optimized Check";
    } else if (checkName.includes("코드형 인프라") || checkName.includes("GitOps") || checkName.includes("latest") || checkName.includes("이미지 태그")) {
        category = "General Check";
        categoryName = "General Check";
    } else {
        // 기본값: 키워드가 없으면 General Check로 분류
        category = "General Check";
        categoryName = "General Check";
    }
    }
    
    // 영문-한글 카테고리 매핑
    const categoryMapping = {
        'General Check': '일반 설정',
        'Security Check': '보안',
        'Scalability Check': '확장성',
        'Stability Check': '안정성',
        'Reliability Check': '안정성',
        'Network Check': '네트워크',
        'Cost-Optimized Check': '비용'
    };
    
    const koreanCategory = categoryMapping[categoryName] || categoryName;
    
    // 해당 카테고리의 PASS 하위 섹션 찾기
    const categorySection = Array.from(document.querySelectorAll('#category-by-type-container .category-section')).find(section => {
        const title = section.querySelector('.category-title h3');
        return title && title.textContent.includes(koreanCategory);
    });
    
    if (!categorySection) {
        console.error(`카테고리 섹션을 찾을 수 없습니다: ${koreanCategory}`);
        return;
    }
    
    // 해당 카테고리 내에서 조치 완료(PASS) 하위 섹션 찾기 또는 생성
    let passContainer = null;
    
    const subSections = categorySection.querySelectorAll('.status-subsection');
    for (const subSection of subSections) {
        const subTitle = subSection.querySelector('.sub-category-title');
        if (subTitle && subTitle.textContent.includes('조치 완료')) {
            passContainer = subSection.querySelector('.status-items');
            break;
        }
    }
    
    // 조치 완료 섹션이 없으면 생성
    if (!passContainer) {
        const statusInfo = {
            title: '조치 완료',
            icon: 'bi-check-circle',
            iconClass: 'success-bg',
            bgClass: 'pass-bg',
            image: 'ico-pass.svg'
        };
        
        const newPassSubSection = createStatusSubSection('PASS', [], statusInfo);
        const categoryContent = categorySection.querySelector('.category-content');
        categoryContent.appendChild(newPassSubSection);
        
        passContainer = newPassSubSection.querySelector('.status-items');
    }
    
    // 이유/런북/리소스 보존하여 PASS 아이템 생성 및 추가
    const preservedReason = savedState && savedState.reasonHTML ? savedState.reasonHTML : '';
    const preservedRunbook = savedState && savedState.runbookHref ? savedState.runbookHref : '';
    const preservedResources = savedState && savedState.resourceHTML ? savedState.resourceHTML : '';
    const newPassItem = createPassItem(checkName, category, preservedReason, preservedRunbook, preservedResources);
    newPassItem.dataset.categoryName = categoryName;
    newPassItem.dataset.status = 'PASS';
    
    passContainer.appendChild(newPassItem);
    console.log(`PASS 섹션에 ${checkName} 항목 추가 완료`);
    
    // 새로 생성된 PASS 아이템의 체크박스에 이벤트 리스너 추가
    setTimeout(() => {
        initManualCheckboxes();
    }, 50);
    
    // 하위 섹션 항목 수 업데이트
    updateSubSectionCounts(categorySection);
    
    console.log(`수동 점검 항목 복원 완료: ${checkName}`);
}

// 수동 점검 상태 초기화 (개발/테스트용)
function clearManualCheckStates() {
    try {
        localStorage.removeItem(MANUAL_CHECK_STORAGE_KEY);
        console.log('수동 점검 상태가 초기화되었습니다.');
        // 페이지 새로고침으로 초기 상태로 복원
        window.location.reload();
    } catch (error) {
        console.error('수동 점검 상태 초기화 중 오류:', error);
    }
}

// 저장된 상태 정보 출력 (개발/디버깅용)
function showManualCheckStates() {
    const savedStates = getManualCheckStates();
    console.log('📊 현재 저장된 수동 점검 상태:', savedStates);
    console.log(`📈 총 체크된 항목 수: ${Object.keys(savedStates).length}`);
    
    if (Object.keys(savedStates).length === 0) {
        console.log('ℹ️ 저장된 체크 항목이 없습니다.');
        return;
    }
    
    console.log('\n📋 체크된 항목 상세 정보:');
    // 체크된 항목들의 상세 정보 출력
    Object.entries(savedStates).forEach(([checkName, state], index) => {
        console.log(`\n${index + 1}. 📝 ${checkName}`);
        console.log(`   ⏰ 체크 시간: ${new Date(state.timestamp).toLocaleString()}`);
        console.log(`   📁 카테고리: ${state.categoryName || 'Unknown'} (${state.category || 'Unknown'})`);
        if (state.url) {
            console.log(`   🔗 URL: ${state.url}`);
        }
    });
    
    // 카테고리별 통계
    const categoryStats = {};
    Object.values(savedStates).forEach(state => {
        const cat = state.categoryName || 'Unknown';
        categoryStats[cat] = (categoryStats[cat] || 0) + 1;
    });
    
    console.log('\n📊 카테고리별 통계:');
    Object.entries(categoryStats).forEach(([category, count]) => {
        console.log(`   ${category}: ${count}개`);
    });
}

// ============================================
// 개발자 도구 지원 및 유틸리티
// ============================================

// localStorage 지원 여부 확인
function isLocalStorageSupported() {
    try {
        const test = 'localStorage-test';
        localStorage.setItem(test, test);
        localStorage.removeItem(test);
        return true;
    } catch (e) {
        console.warn('localStorage가 지원되지 않거나 비활성화되어 있습니다. 수동 점검 상태가 저장되지 않습니다.');
        return false;
    }
}

// 개발자 도구에서 사용할 수 있도록 전역 함수 노출
if (typeof window !== 'undefined') {
    window.eksChecklistUtils = {
        // localStorage 관련 함수들
        showManualCheckStates: showManualCheckStates,
        clearManualCheckStates: clearManualCheckStates,
        getManualCheckStates: getManualCheckStates,
        isLocalStorageSupported: isLocalStorageSupported,
        
        // 점수 및 카운트 관련 함수들
        calculateAndDisplayScore: calculateAndDisplayScore,
        updateCategoryBoxCounts: updateCategoryBoxCounts,
        updateCategoryCounts: updateCategoryCounts,
        
        // 테스트 함수들:
        testScoreCircle: function(pass, manual, fail) {
            console.log(`🧪 점수 원형 차트 테스트: Pass=${pass}%, Manual=${manual}%, Fail=${fail}%`);
            updateScoreCircle(pass, fail, manual, pass >= 80 ? '우수' : pass >= 60 ? '양호' : pass >= 40 ? '주의' : '위험');
            updateScoreDisplay(pass, pass >= 80 ? '우수' : pass >= 60 ? '양호' : pass >= 40 ? '주의' : '위험');
        },
        
        // 도움말 출력
        help: function() {
            console.log(`
🔧 EKS Checklist 개발자 유틸리티

📊 상태 확인:
- eksChecklistUtils.showManualCheckStates()     저장된 체크 상태 확인
- eksChecklistUtils.getManualCheckStates()      저장된 상태 데이터 반환
- eksChecklistUtils.isLocalStorageSupported()  localStorage 지원 여부

🔄 상태 관리:
- eksChecklistUtils.clearManualCheckStates()   모든 체크 상태 초기화 (페이지 새로고침)

📈 점수/카운트 업데이트:
- eksChecklistUtils.calculateAndDisplayScore() 점수 재계산
- eksChecklistUtils.updateCategoryBoxCounts()  카테고리 박스 카운트 업데이트
- eksChecklistUtils.updateCategoryCounts()     전체 카운트 업데이트

🧪 테스트 함수:
- eksChecklistUtils.testScoreCircle(pass, manual, fail)  3색 원형 차트 테스트
  예: eksChecklistUtils.testScoreCircle(60, 25, 15)

❓ 도움말:
- eksChecklistUtils.help()                     이 도움말 표시
            `);
        }
    };
    
    // 페이지 로드 시 localStorage 지원 확인
    if (!isLocalStorageSupported()) {
        // 사용자에게 알림 표시 (선택사항)
        setTimeout(() => {
            console.warn('⚠️ 브라우저에서 localStorage를 지원하지 않아 수동 점검 상태가 저장되지 않습니다.');
        }, 1000);
    } else {
        console.log('✅ localStorage가 지원됩니다. 수동 점검 상태가 자동으로 저장됩니다.');
    }
    
    // 개발자 도구 사용법 안내
    console.log(`
🛠️ 개발자 도구에서 다음과 같이 사용하세요:
- eksChecklistUtils.help()              도움말 보기
- eksChecklistUtils.showManualCheckStates()  저장된 상태 확인
    `);
} 

//0829 추가
// 툴바에 '코드복사' 버튼 추가
Prism.plugins.NormalizeWhitespace.setDefaults({
    'remove-trailing': true,
    'remove-indent': true,
    'left-trim': true,
    'right-trim': true
});

// 한국어 복사 버튼(툴바에 삽입)
Prism.plugins.toolbar.registerButton('copy-ko', function (env) {
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = '코드복사';

    button.addEventListener('click', function () {
        const text = env.element.textContent;
        navigator.clipboard.writeText(text).then(() => {
            const old = button.textContent;
            button.textContent = '복사됨!';
            setTimeout(() => {
                button.textContent = old;
            }, 1200);
        });
    });

    return button;
});

//0829 추가
// 페이지 로드 시 하이라이트
document.addEventListener('DOMContentLoaded', () => {
    Prism.highlightAll();
});